import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTransactionSchema } from "@shared/schema";
import { setupAuth } from "./auth";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Get all transactions (admin only)
  app.get("/api/transactions", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = req.user;
    if (!user || user.isAdmin !== 1) {
      return res.status(403).json({ message: "Admin access required" });
    }
    
    const transactions = await storage.getAllTransactions();
    res.json(transactions);
  });
  
  // Get user transactions
  app.get("/api/user/transactions", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userId = req.user!.id;
    const transactions = await storage.getUserTransactions(userId);
    res.json(transactions);
  });
  
  // Create a new transaction
  app.post("/api/transactions", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = req.user!.id;
      
      // Additional validation
      const createTransactionSchema = insertTransactionSchema.extend({
        fromCrypto: z.string().min(1),
        toCrypto: z.string().min(1),
        fromAmount: z.number().positive(),
        toAmount: z.number().positive(),
        feeAmount: z.number().nonnegative(),
        status: z.enum(["pending", "processing", "completed", "failed"])
      });
      
      const validData = createTransactionSchema.parse({
        ...req.body,
        userId,
      });
      
      const transaction = await storage.createTransaction(validData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });
  
  // Update transaction status
  app.patch("/api/transactions/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const user = req.user;
      if (!user || user.isAdmin !== 1) {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!["pending", "processing", "completed", "failed"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const transaction = await storage.getTransaction(id);
      if (!transaction) {
        return res.status(404).json({ message: "Transaction not found" });
      }
      
      await storage.updateTransactionStatus(id, status);
      res.status(200).json({ message: "Transaction updated" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update transaction" });
    }
  });
  
  // Get cryptocurrencies (mock data)
  app.get("/api/cryptocurrencies", (req, res) => {
    res.json([
      { id: "btc", name: "Bitcoin", symbol: "BTC", price: 42854.21, change24h: 2.34 },
      { id: "eth", name: "Ethereum", symbol: "ETH", price: 2738.65, change24h: 3.12 },
      { id: "bnb", name: "Binance Coin", symbol: "BNB", price: 398.65, change24h: -1.54 },
      { id: "sol", name: "Solana", symbol: "SOL", price: 108.27, change24h: 5.87 },
      { id: "xrp", name: "XRP", symbol: "XRP", price: 0.58, change24h: 1.23 },
      { id: "ada", name: "Cardano", symbol: "ADA", price: 0.48, change24h: -0.85 },
      { id: "doge", name: "Dogecoin", symbol: "DOGE", price: 0.13, change24h: 4.32 },
      { id: "dot", name: "Polkadot", symbol: "DOT", price: 7.86, change24h: 0.95 }
    ]);
  });
  
  // Calculate exchange rates - simulates a connection to a licensed exchange API
  app.post("/api/calculate", (req, res) => {
    if (!req.body.fromCrypto || !req.body.toCrypto || !req.body.amount) {
      return res.status(400).json({ message: "Missing required fields" });
    }
    
    const { fromCrypto, toCrypto, amount } = req.body;
    const fiatCurrency = req.body.fiatCurrency || "USD"; // Default to USD if not provided
    
    // Note: In production, this would call a real exchange API
    // For now, we're using exchange rates that would normally come from the exchange
    const mockRates: Record<string, Record<string, number>> = {
      "BTC": { "ETH": 15.76, "BNB": 107.54, "SOL": 396.22, "XRP": 73900.69, "ADA": 89279.60, "DOGE": 329649.23, "DOT": 5452.19 },
      "ETH": { "BTC": 0.0634, "BNB": 6.82, "SOL": 25.14, "XRP": 4688.55, "ADA": 5663.85, "DOGE": 20915.76, "DOT": 346.14 },
      "BNB": { "BTC": 0.0093, "ETH": 0.1466, "SOL": 3.68, "XRP": 687.33, "ADA": 830.52, "DOGE": 3066.54, "DOT": 50.72 },
      "SOL": { "BTC": 0.0025, "ETH": 0.0398, "BNB": 0.2717, "XRP": 186.67, "ADA": 225.56, "DOGE": 832.92, "DOT": 13.78 },
      "XRP": { "BTC": 0.000014, "ETH": 0.000213, "BNB": 0.001455, "SOL": 0.005357, "ADA": 1.21, "DOGE": 4.46, "DOT": 0.0738 },
      "ADA": { "BTC": 0.000011, "ETH": 0.000177, "BNB": 0.001204, "SOL": 0.004434, "XRP": 0.8264, "DOGE": 3.69, "DOT": 0.0610 },
      "DOGE": { "BTC": 0.000003, "ETH": 0.000048, "BNB": 0.000326, "SOL": 0.001201, "XRP": 0.2242, "ADA": 0.2710, "DOT": 0.0165 },
      "DOT": { "BTC": 0.000183, "ETH": 0.002889, "BNB": 0.01971, "SOL": 0.07257, "XRP": 13.55, "ADA": 16.38, "DOGE": 60.46 }
    };
    
    // This simulates checking with an exchange API for valid trading pairs
    if (!mockRates[fromCrypto] || !mockRates[fromCrypto][toCrypto]) {
      return res.status(400).json({ message: "Unsupported trading pair" });
    }
    
    // Mock crypto prices that would be fetched from the exchange API
    const cryptoPrices: Record<string, number> = {
      "BTC": 42854.21,
      "ETH": 2738.65, 
      "BNB": 398.65,
      "SOL": 108.27,
      "XRP": 0.58,
      "ADA": 0.48,
      "DOGE": 0.13,
      "DOT": 7.86
    };
    
    // Calculate based on exchange rates
    const rate = mockRates[fromCrypto][toCrypto];
    
    // Calculate the actual crypto amount from fiat amount
    const cryptoAmount = amount / cryptoPrices[fromCrypto];
    const convertedAmount = cryptoAmount * rate;
    const fee = convertedAmount * 0.02; // 2% fee
    const finalAmount = convertedAmount - fee;
    
    res.json({
      fromCrypto,
      toCrypto,
      fromAmount: amount,
      fromCryptoAmount: cryptoAmount,
      toAmount: finalAmount,
      rate,
      fee,
      networkFee: cryptoAmount * 0.0005, // Small network fee
      fiatCurrency
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
