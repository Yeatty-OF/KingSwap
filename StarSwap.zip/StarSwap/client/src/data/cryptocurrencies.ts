export interface Cryptocurrency {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change24h: number;
  color: string;
}

export const cryptocurrencies: Cryptocurrency[] = [
  {
    id: "btc",
    name: "Bitcoin",
    symbol: "BTC",
    price: 42854.21,
    change24h: 2.34,
    color: "bg-orange-500"
  },
  {
    id: "eth",
    name: "Ethereum",
    symbol: "ETH",
    price: 2738.65,
    change24h: 3.12,
    color: "bg-blue-500"
  },
  {
    id: "bnb",
    name: "Binance Coin",
    symbol: "BNB",
    price: 398.65,
    change24h: -1.54,
    color: "bg-yellow-500"
  },
  {
    id: "sol",
    name: "Solana",
    symbol: "SOL",
    price: 108.27,
    change24h: 5.87,
    color: "bg-green-500"
  },
  {
    id: "xrp",
    name: "XRP",
    symbol: "XRP",
    price: 0.58,
    change24h: 1.23,
    color: "bg-indigo-500"
  },
  {
    id: "ada",
    name: "Cardano",
    symbol: "ADA",
    price: 0.48,
    change24h: -0.85,
    color: "bg-blue-600"
  },
  {
    id: "doge",
    name: "Dogecoin",
    symbol: "DOGE",
    price: 0.13,
    change24h: 4.32,
    color: "bg-yellow-400"
  },
  {
    id: "dot",
    name: "Polkadot",
    symbol: "DOT",
    price: 7.86,
    change24h: 0.95,
    color: "bg-pink-500"
  }
];

export const getExchangeRate = (fromSymbol: string, toSymbol: string): number => {
  const mockRates: Record<string, Record<string, number>> = {
    "BTC": { "ETH": 15.76, "BNB": 107.54, "SOL": 396.22, "XRP": 73900.69, "ADA": 89279.60, "DOGE": 329649.23, "DOT": 5452.19 },
    "ETH": { "BTC": 0.0634, "BNB": 6.82, "SOL": 25.14, "XRP": 4688.55, "ADA": 5663.85, "DOGE": 20915.76, "DOT": 346.14 },
    "BNB": { "BTC": 0.0093, "ETH": 0.1466, "SOL": 3.68, "XRP": 687.33, "ADA": 830.52, "DOGE": 3066.54, "DOT": 50.72 },
    "SOL": { "BTC": 0.0025, "ETH": 0.0398, "BNB": 0.2717, "XRP": 186.67, "ADA": 225.56, "DOGE": 832.92, "DOT": 13.78 },
    "XRP": { "BTC": 0.000014, "ETH": 0.000213, "BNB": 0.001455, "SOL": 0.005357, "ADA": 1.21, "DOGE": 4.46, "DOT": 0.0738 },
    "ADA": { "BTC": 0.000011, "ETH": 0.000177, "BNB": 0.001204, "SOL": 0.004434, "XRP": 0.8264, "DOGE": 3.69, "DOT": 0.0610 },
    "DOGE": { "BTC": 0.000003, "ETH": 0.000048, "BNB": 0.000326, "SOL": 0.001201, "XRP": 0.2242, "ADA": 0.2710, "DOT": 0.0165 },
    "DOT": { "BTC": 0.000183, "ETH": 0.002889, "BNB": 0.01971, "SOL": 0.07257, "XRP": 13.55, "ADA": 16.38, "DOGE": 60.46 }
  };
  
  if (fromSymbol === toSymbol) return 1;
  
  return mockRates[fromSymbol]?.[toSymbol] || 0;
};
