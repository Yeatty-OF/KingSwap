import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format a number to a specific number of decimal places
export function formatNumber(value: number, decimals: number = 2): string {
  return value.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

// Format crypto amount based on symbol
export function formatCryptoAmount(amount: number, symbol: string): string {
  const decimals = symbol === "BTC" ? 8 : 6;
  return formatNumber(amount, decimals);
}

// Format currency amount
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

// Format date to relative time (e.g. "2 min ago")
export function formatRelativeTime(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) {
    return `${days} day${days > 1 ? 's' : ''} ago`;
  } else if (hours > 0) {
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  } else if (minutes > 0) {
    return `${minutes} min ago`;
  } else {
    return 'just now';
  }
}

// Get transaction status color
export function getStatusColor(status: string): string {
  switch (status) {
    case 'completed':
      return 'bg-green-900 text-green-300';
    case 'pending':
      return 'bg-orange-900 text-orange-300';
    case 'processing':
      return 'bg-yellow-900 text-yellow-300';
    case 'failed':
      return 'bg-red-900 text-red-300';
    default:
      return 'bg-gray-700 text-gray-300';
  }
}

// Get change percentage color
export function getChangeColor(change: number): string {
  return change >= 0 ? 'text-green-500' : 'text-red-500';
}
