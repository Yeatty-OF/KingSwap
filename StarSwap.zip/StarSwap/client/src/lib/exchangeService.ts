// Exchange Service Integration
// This service connects to a licensed exchange (like Binance) through their API

import { apiRequest } from "./queryClient";

// Exchange rate conversion constants
const EXCHANGE_RATE_EUR_USD = 1.07; // 1 EUR = 1.07 USD approximately

export type FiatCurrency = "USD" | "EUR";
export type Language = "EN" | "DE";

interface ExchangeRateResult {
  fromCrypto: string;
  toCrypto: string;
  fromAmount: number; // in fiat
  fromCryptoAmount: number; // actual crypto amount
  toAmount: number; // in crypto
  toCryptoInFiat: number; // value in selected fiat
  rate: number;
  fee: number;
  networkFee: number;
  fiatCurrency: FiatCurrency;
}

// Function to perform exchange rate calculation
export async function calculateExchangeRate(
  fromCrypto: string,
  toCrypto: string,
  amount: number,
  fiatCurrency: FiatCurrency
): Promise<ExchangeRateResult> {
  try {
    // In a real implementation, this would call the exchange API
    // For now, we're using our mock calculation endpoint
    const response = await apiRequest("POST", "/api/calculate", {
      fromCrypto,
      toCrypto,
      amount,
    });

    const data = await response.json();
    
    // Convert based on actual crypto prices
    // The amount provided is in fiat (USD/EUR)
    const fromCryptoPrice = getCryptoPrice(fromCrypto, fiatCurrency);
    
    // Calculate actual crypto amount based on fiat value
    const fromCryptoAmount = amount / fromCryptoPrice;
    
    // Calculate fiat value of destination crypto
    const toCryptoPrice = getCryptoPrice(toCrypto, fiatCurrency);
    const toCryptoInFiat = data.toAmount * toCryptoPrice;
    
    return {
      ...data,
      fromAmount: amount,
      fromCryptoAmount,
      toCryptoInFiat,
      fiatCurrency,
    };
  } catch (error) {
    throw new Error(`Failed to calculate exchange rate: ${error}`);
  }
}

// Function to get current crypto price in specified fiat currency
export function getCryptoPrice(cryptoSymbol: string, fiatCurrency: FiatCurrency): number {
  // These would typically come from the exchange API
  // Using static prices for demonstration
  const pricesInUSD: Record<string, number> = {
    "BTC": 42854.21,
    "ETH": 2738.65,
    "BNB": 398.65,
    "SOL": 108.27,
    "XRP": 0.58,
    "ADA": 0.48,
    "DOGE": 0.13,
    "DOT": 7.86,
  };
  
  // If EUR, convert from USD price
  if (fiatCurrency === "EUR") {
    return pricesInUSD[cryptoSymbol] / EXCHANGE_RATE_EUR_USD;
  }
  
  return pricesInUSD[cryptoSymbol];
}

// Function to perform the actual exchange (would connect to exchange API)
export async function executeExchange(
  fromCrypto: string,
  toCrypto: string,
  amount: number,
  fiatCurrency: FiatCurrency
): Promise<string> {
  try {
    // This is where we would integrate with the exchange's API 
    // For demonstration, we're using our mock transaction endpoint
    const exchangeRate = await calculateExchangeRate(fromCrypto, toCrypto, amount, fiatCurrency);
    
    const response = await apiRequest("POST", "/api/transactions", {
      fromCrypto,
      toCrypto,
      fromAmount: exchangeRate.fromCryptoAmount,
      toAmount: exchangeRate.toAmount,
      feeAmount: exchangeRate.fee,
      status: "pending",
      fiatAmount: amount,
      fiatCurrency,
    });
    
    const data = await response.json();
    return data.id; // Transaction ID
  } catch (error) {
    throw new Error(`Exchange failed: ${error}`);
  }
}

// Formats a number as currency
export function formatFiatAmount(amount: number, currency: FiatCurrency): string {
  return new Intl.NumberFormat('en-US', { 
    style: 'currency', 
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2 
  }).format(amount);
}

// Get minimum fiat amount required for transaction
export function getMinimumFiatAmount(currency: FiatCurrency): number {
  return currency === "EUR" ? 5.00 : 5.00;
}

// Validate if amount meets minimum requirements
export function validateTransactionAmount(amount: number, currency: FiatCurrency): boolean {
  const minimumAmount = getMinimumFiatAmount(currency);
  return amount >= minimumAmount;
}