// ... (other imports and code)

const mockCryptos = [
  { id: "btc", name: "Bitcoin", symbol: "BTC", price: 42854.21, change24h: 2.34 },
  { id: "eth", name: "Ethereum", symbol: "ETH", price: 2738.65, change24h: 1.56 },
  { id: "bnb", name: "BNB", symbol: "BNB", price: 398.65, change24h: -0.45 },
  { id: "sol", name: "Solana", symbol: "SOL", price: 108.27, change24h: 5.67 },
  { id: "xrp", name: "XRP", symbol: "XRP", price: 0.58, change24h: 1.23 },
  { id: "ada", name: "Cardano", symbol: "ADA", price: 0.48, change24h: -2.15 },
  { id: "doge", name: "Dogecoin", symbol: "DOGE", price: 0.13, change24h: 3.45 },
  { id: "dot", name: "Polkadot", symbol: "DOT", price: 7.86, change24h: 0.78 },
  { id: "link", name: "Chainlink", symbol: "LINK", price: 15.23, change24h: 4.56 },
  { id: "matic", name: "Polygon", symbol: "MATIC", price: 0.89, change24h: -1.23 },
  { id: "avax", name: "Avalanche", symbol: "AVAX", price: 34.56, change24h: 2.34 },
  { id: "uni", name: "Uniswap", symbol: "UNI", price: 6.78, change24h: 1.45 },
  { id: "atom", name: "Cosmos", symbol: "ATOM", price: 9.87, change24h: -0.67 },
  { id: "ltc", name: "Litecoin", symbol: "LTC", price: 100.23, change24h: 0.5 },
  { id: "bch", name: "Bitcoin Cash", symbol: "BCH", price: 200.12, change24h: -1.0 },
  { id: "xlm", name: "Stellar", symbol: "XLM", price: 0.15, change24h: 2.2 },
  { id: "etc", name: "Ethereum Classic", symbol: "ETC", price: 25.45, change24h: -0.8 },
  { id: "xmr", name: "Monero", symbol: "XMR", price: 150.67, change24h: 1.5 },
  { id: "dash", name: "Dash", symbol: "DASH", price: 60.34, change24h: -0.2 },
  { id: "zec", name: "Zcash", symbol: "ZEC", price: 80.78, change24h: 3.1 },
  { id: "neo", name: "Neo", symbol: "NEO", price: 20.98, change24h: 0.9 },
  { id: "eos", name: "EOS", symbol: "EOS", price: 3.56, change24h: -1.7 },
  { id: "trx", name: "TRON", symbol: "TRX", price: 0.06, change24h: 0.3 },
  { id: "xtz", name: "Tezos", symbol: "XTZ", price: 2.12, change24h: 1.1 },
  { id: "vet", name: "VeChain", symbol: "VET", price: 0.02, change24h: -0.5 },
  { id: "ont", name: "Ontology", symbol: "ONT", price: 1.23, change24h: 0.7 },
  { id: "iotx", name: "IoTeX", symbol: "IOTX", price: 0.08, change24h: 2.5 },
  { id: "zil", name: "Zilliqa", symbol: "ZIL", price: 0.04, change24h: -1.2 },
  { id: "waves", name: "Waves", symbol: "WAVES", price: 10.56, change24h: 1.8 },
  { id: "near", name: "NEAR Protocol", symbol: "NEAR", price: 3.87, change24h: 0.2 },
  { id: "hbar", name: "Hedera Hashgraph", symbol: "HBAR", price: 0.11, change24h: -0.9 },
  { id: "ftm", name: "Fantom", symbol: "FTM", price: 0.25, change24h: 3.0 },
  { id: "one", name: "Harmony", symbol: "ONE", price: 0.02, change24h: -0.7 },
  { id: "qtum", name: "Qtum", symbol: "QTUM", price: 4.56, change24h: 0.6 },
  { id: "icx", name: "ICON", symbol: "ICX", price: 1.98, change24h: -0.3 },
  { id: "elf", name: "ELF", symbol: "ELF", price: 0.18, change24h: 1.4 },
  { id: "omg", name: "OMG Network", symbol: "OMG", price: 4.23, change24h: -0.1 },

  // ... (465 more cryptocurrency entries -  This is a placeholder,  replace with actual data)
  //Adding 465 more entries to reach 500
  ...Array.from({length: 465}, (_, i) => ({
    id: `crypto${i+38}`,
    name: `Cryptocurrency ${i+38}`,
    symbol: `CRYPTO${i+38}`,
    price: Math.random() * 1000,
    change24h: (Math.random() - 0.5) * 10,
  }))
];


// ... (rest of the component code,  remove "View All Cryptocurrencies" button -  This is a placeholder.  You must provide the original code.)