
import { Link } from "wouter";

export default function SecurityPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">Security</h1>
      <div className="prose prose-invert max-w-none">
        <p>At xSwapStar, we prioritize the security of your assets and personal information. Our platform implements industry-leading security measures:</p>
        
        <ul className="list-disc pl-6 mt-4 space-y-2">
          <li>Non-custodial trading - we never hold your private keys</li>
          <li>End-to-end encryption for all transactions</li>
          <li>Regular security audits by independent firms</li>
          <li>Multi-signature technology for enhanced protection</li>
          <li>Advanced DDoS protection and monitoring</li>
          <li>Compliance with global security standards</li>
        </ul>

        <h2 className="text-2xl font-semibold mt-8 mb-4">Your Security Responsibility</h2>
        <p>While we maintain high security standards, we recommend users to:</p>
        <ul className="list-disc pl-6 mt-4 space-y-2">
          <li>Enable two-factor authentication</li>
          <li>Use strong, unique passwords</li>
          <li>Never share private keys or recovery phrases</li>
          <li>Verify all transaction details before confirming</li>
        </ul>
      </div>
    </div>
  );
}
