import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { SwapWidget } from "@/components/swap/SwapWidget";
import { CryptocurrencyCard } from "@/components/crypto/CryptocurrencyCard";
import { FeatureCard } from "@/components/features/FeatureCard";
import { StepCard } from "@/components/steps/StepCard";
import { StarBackground } from "@/components/animations/StarBackground";
import { useQuery } from "@tanstack/react-query";
import { Zap, Shield, Percent } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

interface Cryptocurrency {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change24h: number;
}

export default function HomePage() {
  const { data: cryptocurrencies = [] } = useQuery<Cryptocurrency[]>({
    queryKey: ["/api/cryptocurrencies"],
  });

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <StarBackground />
      <Header />

      <main className="relative z-10">
        {/* Hero Section */}
        <section className="relative py-16 md:py-24">
          <div className="container mx-auto px-4 text-center">
            <motion.h1 
              className="text-4xl md:text-5xl lg:text-6xl font-bold font-sans mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-purple-500">
                Swap Crypto with Stellar Speed
              </span>
            </motion.h1>

            <motion.p 
              className="text-lg text-gray-300 max-w-2xl mx-auto mb-10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Fast, secure, and interstellar cryptocurrency swaps with the best rates in the cosmos.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <SwapWidget />
            </motion.div>
          </div>
        </section>

        {/* Cryptocurrency Section */}
        <section className="py-16 bg-gray-800 bg-opacity-50 relative overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold font-sans mb-4">Popular Cryptocurrencies</h2>
              <p className="text-gray-400 max-w-2xl mx-auto">Swap your crypto assets instantly with the best rates in the galaxy.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {cryptocurrencies.slice(0, 4).map((crypto) => (
                <CryptocurrencyCard
                  key={crypto.id}
                  id={crypto.id}
                  name={crypto.name}
                  symbol={crypto.symbol}
                  price={crypto.price}
                  change24h={crypto.change24h}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 relative">
          <div className="container mx-auto px-4">
            <div className="text-center mb-14">
              <h2 className="text-3xl font-bold font-sans mb-4">Why Choose StarSwap</h2>
              <p className="text-gray-400 max-w-2xl mx-auto">Our interstellar platform offers unparalleled trading experience with cosmic benefits.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FeatureCard
                icon={Zap}
                title="Lightning Fast Swaps"
                description="Complete your transactions in seconds with our optimized exchange protocol."
              />
              <FeatureCard
                icon={Shield}
                title="Stellar Security"
                description="Your assets are protected by enterprise-grade security and encryption protocols."
              />
              <FeatureCard
                icon={Percent}
                title="Transparent Fees"
                description="Just 2% fee for all transactions. No hidden costs or surprise charges ever."
              />
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-16 bg-gray-800 bg-opacity-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-14">
              <h2 className="text-3xl font-bold font-sans mb-4">How StarSwap Works</h2>
              <p className="text-gray-400 max-w-2xl mx-auto">Swapping cryptocurrencies has never been easier. Follow these simple steps:</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <StepCard
                number={1}
                title="Select Crypto"
                description="Choose the cryptocurrency you want to exchange and the one you want to receive."
              />
              <StepCard
                number={2}
                title="Review Details"
                description="Check the exchange rate, fees, and estimated time to complete the transaction."
              />
              <StepCard
                number={3}
                title="Complete Swap"
                description="Confirm the transaction details and your exchange will be processed instantly."
                isLast
              />
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}