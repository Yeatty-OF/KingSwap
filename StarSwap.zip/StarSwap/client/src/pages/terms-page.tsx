
import { Link } from "wouter";

export default function TermsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">Terms of Service</h1>
      <div className="prose prose-invert max-w-none">
        <p>These Terms of Service govern your use of xSwapStar platform. By using our services, you agree to these terms.</p>

        <h2 className="text-2xl font-semibold mt-8 mb-4">1. Service Description</h2>
        <p>xSwapStar provides a decentralized cryptocurrency exchange platform. We facilitate crypto-to-crypto transactions without taking custody of user funds.</p>

        <h2 className="text-2xl font-semibold mt-8 mb-4">2. User Responsibilities</h2>
        <p>Users are responsible for:</p>
        <ul className="list-disc pl-6 mt-4 space-y-2">
          <li>Maintaining the security of their wallet and private keys</li>
          <li>Ensuring compliance with their local regulations</li>
          <li>Verifying all transaction details before confirmation</li>
        </ul>

        <h2 className="text-2xl font-semibold mt-8 mb-4">3. Service Availability</h2>
        <p>While we strive for continuous operation, we cannot guarantee uninterrupted access to our services.</p>

        <h2 className="text-2xl font-semibold mt-8 mb-4">4. Compliance</h2>
        <p>Users must ensure compliance with their local laws and regulations. The platform is not available in restricted jurisdictions.</p>

        <h2 className="text-2xl font-semibold mt-8 mb-4">5. Limitation of Liability</h2>
        <p>xSwapStar is not liable for any losses incurred through platform use, including but not limited to trading losses or technical issues.</p>
      </div>
    </div>
  );
}
