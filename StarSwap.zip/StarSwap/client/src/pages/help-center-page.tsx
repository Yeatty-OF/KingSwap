import { Link } from "wouter";

import React from 'react';

export default function HelpCenterPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">Help Center</h1>
      <div className="prose prose-invert max-w-none">
        <p className="text-xl mb-6">Need assistance? Contact our support team:</p>
        <div className="bg-gray-800 p-6 rounded-lg">
          <h2 className="text-2xl font-semibold mb-4">Contact Support</h2>
          <p>Email: [Support email will be added later]</p>
          <p className="mt-4">Our team typically responds within 24 hours.</p>
        </div>
      </div>
    </div>
  );
}