
import { Button } from "@/components/ui/button"
import { Link } from "wouter"

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">About StarSwap</h1>
      <div className="prose prose-invert max-w-none">
        <p className="text-lg mb-4">
          StarSwap is a cutting-edge cryptocurrency exchange platform designed to provide seamless, secure, and efficient trading experiences. Our mission is to make cryptocurrency trading accessible to everyone while maintaining the highest standards of security and performance.
        </p>
        <h2 className="text-2xl font-semibold mt-8 mb-4">Our Vision</h2>
        <p className="mb-4">
          We aim to become the most trusted and user-friendly cryptocurrency exchange in the digital asset space, connecting traders across the globe through innovative technology and exceptional service.
        </p>
        <h2 className="text-2xl font-semibold mt-8 mb-4">Key Features</h2>
        <ul className="list-disc pl-6 mb-6">
          <li className="mb-2">Real-time cryptocurrency price updates</li>
          <li className="mb-2">Secure wallet integration</li>
          <li className="mb-2">Advanced trading features</li>
          <li className="mb-2">24/7 support</li>
          <li className="mb-2">Multi-currency support</li>
        </ul>
        <div className="mt-8">
          <Link href="/">
            <Button>Return Home</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
