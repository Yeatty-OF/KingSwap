
import React from 'react';

export default function ApiDocsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">API Documentation</h1>
      <div className="prose prose-invert max-w-none">
        <p>Welcome to the xSwapStar API documentation. Our API enables you to:</p>
        
        <ul className="list-disc pl-6 mt-4 space-y-2">
          <li>Access real-time cryptocurrency prices</li>
          <li>Execute swaps programmatically</li>
          <li>Retrieve transaction history</li>
          <li>Monitor exchange rates</li>
        </ul>

        <h2 className="text-2xl font-semibold mt-8 mb-4">Getting Started</h2>
        <p>For integration details and API endpoints, please contact our support team.</p>
      </div>
    </div>
  );
}
