import { useState } from "react";
import { Header } from "@/components/layout/Header";
import { StarBackground } from "@/components/animations/StarBackground";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { CryptoLogo } from "@/components/animations/CryptoLogo";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  ArrowUp, 
  Users, 
  DollarSign, 
  PercentCircle,
  RefreshCw 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { formatRelativeTime, getStatusColor } from "@/lib/utils";

interface Transaction {
  id: number;
  userId: number;
  fromCrypto: string;
  toCrypto: string;
  fromAmount: number;
  toAmount: number;
  feeAmount: number;
  status: string;
  createdAt: string;
}

interface AdminStats {
  totalTransactions: number;
  activeUsers: number;
  totalVolume: number;
  feeRevenue: number;
  weeklyGrowth: number;
}

export default function AdminPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedStatus, setSelectedStatus] = useState<Record<number, string>>({});
  
  // Fetch transactions
  const { data: transactions = [], isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });
  
  // Calculate admin stats
  const adminStats: AdminStats = {
    totalTransactions: transactions.length,
    activeUsers: Array.from(new Set(transactions.map(tx => tx.userId))).length,
    totalVolume: transactions.reduce((sum, tx) => sum + tx.fromAmount, 0),
    feeRevenue: transactions.reduce((sum, tx) => sum + tx.feeAmount, 0),
    weeklyGrowth: 14.7,
  };
  
  // Update transaction status
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      await apiRequest("PATCH", `/api/transactions/${id}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Status updated",
        description: "Transaction status has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleStatusChange = (id: number, status: string) => {
    setSelectedStatus(prev => ({ ...prev, [id]: status }));
  };
  
  const handleUpdateStatus = (id: number) => {
    const status = selectedStatus[id];
    if (status) {
      updateStatusMutation.mutate({ id, status });
    }
  };
  
  if (!user || user.isAdmin !== 1) {
    return null; // Protected route should handle this, but just in case
  }
  
  return (
    <div className="min-h-screen bg-gray-900 text-white pb-20">
      <StarBackground />
      <Header />
      
      <main className="relative z-10 py-8">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold font-sans text-white flex items-center">
                <span className="text-amber-400 mr-1">★</span>
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-purple-500">StarSwap</span>
                <span className="ml-2 px-3 py-1 bg-purple-500 text-xs rounded-lg">Admin</span>
              </h1>
            </div>
          </div>
          
          {/* Admin Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Total Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold">{adminStats.totalTransactions.toLocaleString()}</div>
                <div className="text-green-500 text-sm mt-2 flex items-center">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  <span>12.5% from last week</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Active Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold">{adminStats.activeUsers.toLocaleString()}</div>
                <div className="text-green-500 text-sm mt-2 flex items-center">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  <span>5.2% from last week</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Total Volume</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold">
                  ${adminStats.totalVolume.toLocaleString(undefined, { 
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2 
                  })}
                </div>
                <div className="text-green-500 text-sm mt-2 flex items-center">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  <span>18.3% from last week</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Fee Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold">
                  ${adminStats.feeRevenue.toLocaleString(undefined, { 
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2 
                  })}
                </div>
                <div className="text-green-500 text-sm mt-2 flex items-center">
                  <ArrowUp className="h-3 w-3 mr-1" />
                  <span>{adminStats.weeklyGrowth}% from last week</span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Transaction List */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="border-b border-gray-700">
              <CardTitle>
                <div className="flex items-center justify-between">
                  <span>Recent Transactions</span>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="border-gray-600"
                    onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/transactions"] })}
                  >
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <div className="overflow-x-auto">
              {isLoading ? (
                <div className="flex justify-center items-center py-20">
                  <RefreshCw className="h-8 w-8 animate-spin text-purple-500" />
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-700 hover:bg-transparent">
                      <TableHead>Transaction ID</TableHead>
                      <TableHead>User ID</TableHead>
                      <TableHead>From</TableHead>
                      <TableHead>To</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Fee</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={9} className="text-center py-8 text-gray-400">
                          No transactions found
                        </TableCell>
                      </TableRow>
                    ) : (
                      transactions.map((tx) => (
                        <TableRow key={tx.id} className="border-gray-700">
                          <TableCell className="font-mono text-sm">#{tx.id.toString().padStart(8, '0')}</TableCell>
                          <TableCell>{tx.userId}</TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <CryptoLogo cryptoSymbol={tx.fromCrypto} size="sm" />
                              <span className="ml-2">{tx.fromAmount.toFixed(6)} {tx.fromCrypto}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center">
                              <CryptoLogo cryptoSymbol={tx.toCrypto} size="sm" />
                              <span className="ml-2">{tx.toAmount.toFixed(6)} {tx.toCrypto}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            ${(tx.fromAmount).toLocaleString(undefined, { 
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2 
                            })}
                          </TableCell>
                          <TableCell className="text-purple-500">
                            ${tx.feeAmount.toLocaleString(undefined, { 
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2 
                            })}
                          </TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 ${getStatusColor(tx.status)} rounded-full text-xs`}>
                              {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                            </span>
                          </TableCell>
                          <TableCell className="text-gray-400">
                            {formatRelativeTime(new Date(tx.createdAt))}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Select
                                value={selectedStatus[tx.id] || tx.status}
                                onValueChange={(value) => handleStatusChange(tx.id, value)}
                              >
                                <SelectTrigger className="h-8 w-[110px] bg-gray-900 border-gray-700">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="pending">Pending</SelectItem>
                                  <SelectItem value="processing">Processing</SelectItem>
                                  <SelectItem value="completed">Completed</SelectItem>
                                  <SelectItem value="failed">Failed</SelectItem>
                                </SelectContent>
                              </Select>
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="h-8 border-gray-700"
                                onClick={() => handleUpdateStatus(tx.id)}
                                disabled={!selectedStatus[tx.id] || selectedStatus[tx.id] === tx.status || updateStatusMutation.isPending}
                              >
                                Update
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              )}
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
