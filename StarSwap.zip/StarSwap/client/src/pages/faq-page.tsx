
import { Button } from "@/components/ui/button"
import { Link } from "wouter"

export default function FAQPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">Frequently Asked Questions</h1>
      <div className="space-y-6">
        <div className="border-b border-gray-700 pb-4">
          <h3 className="text-xl font-semibold mb-2">How do I start trading?</h3>
          <p>To start trading, simply connect your wallet and select the cryptocurrencies you wish to exchange. Our platform will automatically find the best rates for your trade.</p>
        </div>
        <div className="border-b border-gray-700 pb-4">
          <h3 className="text-xl font-semibold mb-2">What currencies do you support?</h3>
          <p>We support over 500 different cryptocurrencies, including major ones like Bitcoin, Ethereum, and many altcoins.</p>
        </div>
        <div className="border-b border-gray-700 pb-4">
          <h3 className="text-xl font-semibold mb-2">Are my funds safe?</h3>
          <p>Yes, we implement industry-leading security measures and never store your private keys. All transactions are processed through secure smart contracts.</p>
        </div>
        <div className="border-b border-gray-700 pb-4">
          <h3 className="text-xl font-semibold mb-2">What are the trading fees?</h3>
          <p>Our fees are competitive and transparent. We charge a small percentage per trade, with discounts available for high-volume traders.</p>
        </div>
        <div className="mt-8">
          <Link href="/">
            <Button>Return Home</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
