import { motion } from "framer-motion";
import { CryptoLogo } from "@/components/animations/CryptoLogo";

interface CryptocurrencyCardProps {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change24h: number;
}

export function CryptocurrencyCard({ name, symbol, price, change24h }: CryptocurrencyCardProps) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="bg-gray-900 rounded-xl p-6 border border-gray-800 hover:border-purple-500 transition duration-300"
    >
      <div className="flex items-center mb-4">
        <CryptoLogo cryptoSymbol={symbol} size="lg" />
        <div className="ml-3">
          <h3 className="font-semibold">{name}</h3>
          <span className="text-sm text-gray-400">{symbol}</span>
        </div>
      </div>
      <div className="flex justify-between text-sm">
        <span className="text-gray-400">Price</span>
        <span className="font-medium">${price.toLocaleString(undefined, { 
          minimumFractionDigits: 2,
          maximumFractionDigits: 2 
        })}</span>
      </div>
      <div className="flex justify-between text-sm mt-1">
        <span className="text-gray-400">24h</span>
        <span className={change24h >= 0 ? "text-green-500" : "text-red-500"}>
          {change24h >= 0 ? "+" : ""}{change24h}%
        </span>
      </div>
    </motion.div>
  );
}
