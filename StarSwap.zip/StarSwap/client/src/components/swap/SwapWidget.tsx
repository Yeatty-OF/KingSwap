import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CryptoLogo } from "@/components/animations/CryptoLogo";
import { FeeAnimation } from "@/components/animations/FeeAnimation";
import { RefreshCw, DollarSign, Euro } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";

interface CryptoCurrency {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change24h: number;
}

interface SwapResult {
  fromCrypto: string;
  toCrypto: string;
  fromAmount: number; // in fiat
  fromCryptoAmount: number; // actual crypto amount
  toAmount: number;
  rate: number;
  fee: number;
  networkFee: number;
  fiatCurrency: string;
}

import {
  executeExchange,
  calculateExchangeRate,
  formatFiatAmount,
  validateTransactionAmount,
  getMinimumFiatAmount,
  FiatCurrency as Currency
} from "@/lib/exchangeService";

export function SwapWidget() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [fromCrypto, setFromCrypto] = useState<string>("BTC");
  const [toCrypto, setToCrypto] = useState<string>("ETH");
  const [fromAmount, setFromAmount] = useState<string>("");
  const [toAmount, setToAmount] = useState<string>("");
  const [swapResult, setSwapResult] = useState<SwapResult | null>(null);
  const [isExchanging, setIsExchanging] = useState<boolean>(false);
  const [fiatCurrency, setFiatCurrency] = useState<Currency>("USD");
  const [language, setLanguage] = useState<"EN" | "DE">("EN");

  // Fetch available cryptocurrencies
  const { data: cryptos = [] } = useQuery<CryptoCurrency[]>({
    queryKey: ["/api/cryptocurrencies"],
  });

  // Calculate exchange using the exchange service
  const calculateMutation = useMutation({
    mutationFn: async (data: { fromCrypto: string; toCrypto: string; amount: number }) => {
      // This is where we would connect to a licensed exchange API in production
      return calculateExchangeRate(
        data.fromCrypto,
        data.toCrypto,
        data.amount,
        fiatCurrency
      );
    },
    onSuccess: (data: SwapResult) => {
      setSwapResult(data);
      setToAmount(data.toAmount.toFixed(8));
    },
    onError: (error: Error) => {
      toast({
        title: language === "EN" ? "Calculation failed" : "Berechnung fehlgeschlagen",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Create transaction through the exchange service
  const createTransactionMutation = useMutation({
    mutationFn: async (data: {
      fromCrypto: string;
      toCrypto: string;
      fromAmount: number;
      fiatCurrency: Currency;
    }) => {
      // This would connect to the exchange API in production
      return executeExchange(
        data.fromCrypto,
        data.toCrypto,
        data.fromAmount,
        data.fiatCurrency
      );
    },
    onSuccess: () => {
      toast({
        title: language === "EN" ? "Success!" : "Erfolg!",
        description: language === "EN" 
          ? "Your exchange has been initiated. Check your transaction history for updates."
          : "Ihr Austausch wurde eingeleitet. Überprüfen Sie Ihren Transaktionsverlauf auf Updates.",
      });
      setIsExchanging(false);
      setFromAmount("");
      setToAmount("");
      setSwapResult(null);
    },
    onError: (error: Error) => {
      toast({
        title: language === "EN" ? "Exchange failed" : "Austausch fehlgeschlagen",
        description: error.message,
        variant: "destructive",
      });
      setIsExchanging(false);
    },
  });

  // Toggle language
  const toggleLanguage = () => {
    setLanguage(prev => prev === "EN" ? "DE" : "EN");
  };

  // Toggle currency
  const toggleCurrency = () => {
    setFiatCurrency(prev => prev === "USD" ? "EUR" : "USD");
  };

  // Handle amount change
  useEffect(() => {
    const amount = parseFloat(fromAmount);
    if (fromAmount && !isNaN(amount) && amount > 0) {
      calculateMutation.mutate({
        fromCrypto,
        toCrypto,
        amount,
      });
    } else {
      setToAmount("");
      setSwapResult(null);
    }
  }, [fromAmount, fromCrypto, toCrypto, fiatCurrency]);

  // Handle crypto selection change
  const handleFromCryptoChange = (value: string) => {
    if (value === toCrypto) {
      setToCrypto(fromCrypto);
    }
    setFromCrypto(value);
  };

  const handleToCryptoChange = (value: string) => {
    if (value === fromCrypto) {
      setFromCrypto(toCrypto);
    }
    setToCrypto(value);
  };

  // Swap direction
  const handleSwapDirection = () => {
    const tempCrypto = fromCrypto;
    const tempAmount = fromAmount;

    setFromCrypto(toCrypto);
    setToCrypto(tempCrypto);

    if (swapResult) {
      setFromAmount(toAmount);
      setToAmount(tempAmount);
    }
  };

  // Start exchange
  const handleStartExchange = async () => {
    if (!user) {
      toast({
        title: language === "EN" ? "Authentication required" : "Authentifizierung erforderlich",
        description: language === "EN" 
          ? "Please login or create an account to swap cryptocurrencies."
          : "Bitte melden Sie sich an oder erstellen Sie ein Konto, um Kryptowährungen zu tauschen.",
      });
      return;
    }

    if (!swapResult || !fromAmount) {
      toast({
        title: language === "EN" ? "Invalid amount" : "Ungültiger Betrag",
        description: language === "EN" 
          ? "Please enter a valid amount to swap."
          : "Bitte geben Sie einen gültigen Betrag zum Tauschen ein.",
      });
      return;
    }

    try {
      setIsExchanging(true);
      await createTransactionMutation.mutateAsync({
        fromCrypto,
        toCrypto,
        fromAmount: parseFloat(fromAmount),
        fiatCurrency
      });
    } catch (error) {
      console.error('Exchange error:', error);
    }

    const amount = parseFloat(fromAmount);

    // Check minimum amount
    if (!validateTransactionAmount(amount, fiatCurrency)) {
      const minAmount = getMinimumFiatAmount(fiatCurrency);
      toast({
        title: language === "EN" ? "Minimum amount required" : "Mindestbetrag erforderlich",
        description: language === "EN"
          ? `Please enter at least ${formatFiatAmount(minAmount, fiatCurrency)}`
          : `Bitte geben Sie mindestens ${formatFiatAmount(minAmount, fiatCurrency)} ein`,
        variant: "destructive",
      });
      return;
    }

    setIsExchanging(true);

    createTransactionMutation.mutate({
      fromCrypto: swapResult.fromCrypto,
      toCrypto: swapResult.toCrypto,
      fromAmount: amount,
      fiatCurrency,
    });
  };

  return (
    <div className="max-w-xl mx-auto">
      <div className="rounded-2xl p-6 md:p-8 shadow-xl bg-gray-900 bg-opacity-70 backdrop-blur-md border border-gray-800">
        {/* Header with language and currency toggles */}
        <div className="flex flex-col space-y-4 mb-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">
              {language === "EN" ? "Instant Swap" : "Sofort-Tausch"}
            </h2>
            <div className="flex items-center text-sm text-gray-400">
              <FeeAnimation feePercentage={2} />
            </div>
          </div>

          {/* Language and Currency Toggles */}
          <div className="flex justify-between">
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                className={`text-xs py-0 h-7 ${language === "EN" ? "bg-purple-900/40 text-purple-300" : "bg-transparent"}`}
                onClick={() => setLanguage("EN")}
              >
                EN
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                className={`text-xs py-0 h-7 ${language === "DE" ? "bg-purple-900/40 text-purple-300" : "bg-transparent"}`}
                onClick={() => setLanguage("DE")}
              >
                DE
              </Button>
            </div>
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                className={`text-xs py-0 h-7 ${fiatCurrency === "USD" ? "bg-amber-900/40 text-amber-300" : "bg-transparent"}`}
                onClick={() => setFiatCurrency("USD")}
              >
                <DollarSign className="h-3.5 w-3.5 mr-1" />
                USD
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                className={`text-xs py-0 h-7 ${fiatCurrency === "EUR" ? "bg-amber-900/40 text-amber-300" : "bg-transparent"}`}
                onClick={() => setFiatCurrency("EUR")}
              >
                <Euro className="h-3.5 w-3.5 mr-1" />
                EUR
              </Button>
            </div>
          </div>
        </div>

        {/* From Currency */}
        <div className="mb-5">
          <label className="block text-sm text-gray-400 mb-2">
            {language === "EN" ? "You Send" : "Sie senden"}
            <span className="text-gray-500 ml-1 text-xs">
              ({language === "EN" ? "Min" : "Mind."} {formatFiatAmount(getMinimumFiatAmount(fiatCurrency), fiatCurrency)})
            </span>
          </label>
          <div className="bg-gray-800 rounded-lg p-4 flex items-center">
            <div className="flex-1 relative">
              <Input
                type="number"
                placeholder="0.00"
                className="bg-transparent text-white text-xl w-full focus:outline-none focus:ring-0 border-none pl-6"
                value={fromAmount}
                onChange={(e) => setFromAmount(e.target.value)}
              />
              <div className="absolute left-0 top-1/2 transform -translate-y-1/2 text-gray-400">
                {fiatCurrency === "USD" ? "$" : "€"}
              </div>
            </div>
            <div className="relative">
              <Select value={fromCrypto} onValueChange={handleFromCryptoChange}>
                <SelectTrigger className="w-[110px] bg-gray-700 hover:bg-gray-600 border-none">
                  <SelectValue placeholder="Select crypto">
                    <div className="flex items-center">
                      <CryptoLogo cryptoSymbol={fromCrypto} size="sm" />
                      <span className="ml-2">{fromCrypto}</span>
                    </div>
                  </SelectValue>
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectGroup>
                    {cryptos.map((crypto) => (
                      <SelectItem key={crypto.id} value={crypto.symbol}>
                        <div className="flex items-center">
                          <CryptoLogo cryptoSymbol={crypto.symbol} size="sm" />
                          <span className="ml-2">{crypto.symbol}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
          </div>
          {swapResult && (
            <div className="text-xs text-gray-500 mt-1 pl-1">
              ≈ {swapResult.fromCryptoAmount.toFixed(8)} {fromCrypto}
            </div>
          )}
        </div>

        {/* Exchange Icon */}
        <div className="flex justify-center -my-2">
          <Button
            variant="outline"
            size="icon"
            className="bg-gray-800 border-none hover:bg-gray-700 rounded-full h-10 w-10"
            onClick={handleSwapDirection}
          >
            <RefreshCw className="h-4 w-4 text-purple-500" />
          </Button>
        </div>

        {/* To Currency */}
        <div className="mb-6 mt-3">
          <label className="block text-sm text-gray-400 mb-2">
            {language === "EN" ? "You Receive" : "Sie erhalten"}
            {swapResult && (
              <span className="text-xs text-amber-400 ml-2">
                (After {language === "EN" ? "2% fee" : "2% Gebühr"}: {formatFiatAmount(swapResult.toAmount * (cryptos.find(c => c.symbol === toCrypto)?.price || 0), fiatCurrency)})
              </span>
            )}
          </label>
          <div className="bg-gray-800 rounded-lg p-4 flex items-center">
            <div className="flex-1 relative">
              <Input
                type="number"
                placeholder="0.00"
                className="bg-transparent text-white text-xl w-full focus:outline-none focus:ring-0 border-none"
                value={toAmount}
                readOnly
              />
            </div>
            <div>
              <Select value={toCrypto} onValueChange={handleToCryptoChange}>
                <SelectTrigger className="w-[110px] bg-gray-700 hover:bg-gray-600 border-none">
                  <SelectValue placeholder="Select crypto">
                    <div className="flex items-center">
                      <CryptoLogo cryptoSymbol={toCrypto} size="sm" />
                      <span className="ml-2">{toCrypto}</span>
                    </div>
                  </SelectValue>
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectGroup>
                    {cryptos.map((crypto) => (
                      <SelectItem key={crypto.id} value={crypto.symbol}>
                        <div className="flex items-center">
                          <CryptoLogo cryptoSymbol={crypto.symbol} size="sm" />
                          <span className="ml-2">{crypto.symbol}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Exchange Rate */}
        <AnimatePresence>
          {swapResult && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="text-sm text-gray-400 mb-6 bg-gray-800 bg-opacity-50 rounded-lg p-3 overflow-hidden"
            >
              <div className="flex justify-between">
                <span>{language === "EN" ? "Exchange Rate" : "Wechselkurs"}</span>
                <span className="text-white">
                  1 {fromCrypto} ≈ {swapResult.rate.toFixed(4)} {toCrypto}
                </span>
              </div>
              <div className="flex justify-between mt-1">
                <span>{language === "EN" ? "Network Fee" : "Netzwerkgebühr"}</span>
                <span className="text-purple-500">
                  {swapResult.networkFee.toFixed(6)} {fromCrypto}
                </span>
              </div>
              <div className="flex justify-between mt-1">
                <span>{language === "EN" ? "StarSwap Fee (2%)" : "StarSwap Gebühr (2%)"}</span>
                <span className="text-amber-400">
                  {swapResult.fee.toFixed(6)} {toCrypto}
                </span>
              </div>
              <div className="border-t border-gray-700 mt-2 pt-2 flex justify-between font-medium">
                <span>{language === "EN" ? "Total Cost" : "Gesamtkosten"}</span>
                <span className="text-white">
                  {formatFiatAmount(parseFloat(fromAmount), fiatCurrency)}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Disclaimer about licensed exchange */}
        <div className="text-xs text-gray-500 italic mb-4 text-center">
          {language === "EN" 
            ? "Powered by licensed exchange partners. StarSwap acts as an interface only."
            : "Unterstützt von lizenzierten Börsenpartnern. StarSwap fungiert nur als Schnittstelle."}
        </div>

        {/* Action Button */}
        {user ? (
          <Button
            onClick={handleStartExchange}
            disabled={!swapResult || isExchanging || createTransactionMutation.isPending || 
                    !validateTransactionAmount(parseFloat(fromAmount) || 0, fiatCurrency)}
            className="w-full py-6 bg-gradient-to-r from-amber-400 to-purple-500 hover:from-purple-500 hover:to-amber-400 rounded-lg font-medium transition duration-300 text-black"
          >
            {isExchanging || createTransactionMutation.isPending ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                {language === "EN" ? "Processing..." : "Verarbeitung..."}
              </>
            ) : (
              language === "EN" ? "Start Exchange" : "Austausch starten"
            )}
          </Button>
        ) : (
          <Link href="/auth">
            <Button className="w-full py-6 bg-gradient-to-r from-amber-400 to-purple-500 hover:from-purple-500 hover:to-amber-400 rounded-lg font-medium transition duration-300 text-black">
              {language === "EN" ? "Login to Start Exchange" : "Anmelden zum Starten des Austauschs"}
            </Button>
          </Link>
        )}
      </div>
    </div>
  );
}