import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

export function FeatureCard({ icon: Icon, title, description }: FeatureCardProps) {
  return (
    <motion.div 
      className="bg-gray-900 bg-opacity-50 rounded-xl p-8 border border-gray-800 relative overflow-hidden group"
      whileHover={{ scale: 1.02 }}
    >
      <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-amber-400 to-purple-500 opacity-10 rounded-bl-full group-hover:opacity-20 transition-opacity duration-300"></div>
      <div className="text-amber-400 mb-4 text-3xl">
        <Icon strokeWidth={1.5} />
      </div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </motion.div>
  );
}
