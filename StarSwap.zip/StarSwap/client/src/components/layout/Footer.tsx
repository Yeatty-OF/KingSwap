import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Send,
  MessagesSquare
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function Footer() {
  const { toast } = useToast();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Success!",
      description: "You've been subscribed to our newsletter.",
    });
  };

  return (
    <footer className="bg-gray-900 border-t border-gray-800 py-10 relative z-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-bold font-sans text-white flex items-center mb-4">
              <span className="text-amber-400 mr-1">★</span>
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-purple-500">StarSwap</span>
            </div>
            <p className="text-gray-400 text-sm">The fastest and most secure cryptocurrency exchange platform in the galaxy.</p>
            <div className="flex mt-4 space-x-3">
              <a href="https://x.com/xswapstar?s=21" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-amber-400 transition duration-300">
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </a>
              <a href="https://t.me/xSwapStar" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-amber-400 transition duration-300">
                <MessagesSquare size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/"><a className="text-gray-400 hover:text-amber-400 transition duration-300">Home</a></Link></li>
              <li><Link href="/#exchange"><a className="text-gray-400 hover:text-amber-400 transition duration-300">Exchange</a></Link></li>
              <li><Link href="/wallet"><a className="text-gray-400 hover:text-amber-400 transition duration-300">Wallet</a></Link></li>
              <li><Link href="/about"><a className="text-gray-400 hover:text-amber-400 transition duration-300">About</a></Link></li>
              <li><Link href="/faq"><a className="text-gray-400 hover:text-amber-400 transition duration-300">FAQ</a></Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/docs/api"><a className="text-gray-400 hover:text-amber-400 transition duration-300">API Documentation</a></Link></li>
              <li><Link href="/help"><a className="text-gray-400 hover:text-amber-400 transition duration-300">Help Center</a></Link></li>
              <li><Link href="/security"><a className="text-gray-400 hover:text-amber-400 transition duration-300">Security</a></Link></li>
              <li><Link href="/terms"><a className="text-gray-400 hover:text-amber-400 transition duration-300">Terms of Service</a></Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4">Newsletter</h4>
            <p className="text-sm text-gray-400 mb-4">Stay updated with our latest features and releases.</p>
            <form onSubmit={handleSubscribe} className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                className="bg-gray-800 border-gray-700"
              />
              <Button type="submit" size="icon">
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; {new Date().getFullYear()} StarSwap. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}