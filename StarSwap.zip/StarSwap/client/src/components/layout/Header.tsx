import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from "@/components/ui/sheet";
import { Menu } from "lucide-react";

export function Header() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navItems = [
    { name: "Home", path: "/" },
    { name: "Exchange", path: "/#exchange" },
    { name: "Wallet", path: "/wallet" }, // Placeholder path
    { name: "About", path: "/about" },
    { name: "FAQ", path: "/faq" },
  ];

  return (
    <header className={`relative z-10 border-b border-gray-800 transition-colors ${isScrolled ? 'bg-gray-900 bg-opacity-90 backdrop-blur-md' : ''}`}>
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/">
              <a className="text-2xl font-bold font-sans text-white flex items-center">
                <span className="text-amber-400 mr-1">★</span>
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-400 to-purple-500">StarSwap</span>
              </a>
            </Link>
          </div>

          <nav className="hidden md:flex space-x-6 text-sm font-medium">
            {navItems.map((item) => (
              <Link key={item.name} href={item.path}>
                <a 
                  className={`transition duration-300 ${
                    location === item.path
                      ? "text-white"
                      : "text-gray-400 hover:text-amber-400"
                  }`}
                >
                  {item.name}
                </a>
              </Link>
            ))}
          </nav>

          <div className="flex items-center space-x-3">
            {user ? (
              <>
                {user.isAdmin === 1 && (
                  <Link href="/admin">
                    <Button variant="ghost" className="text-sm">
                      Admin
                    </Button>
                  </Link>
                )}
                <Button variant="ghost" size="sm" onClick={handleLogout} className="text-sm">
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Link href="/auth">
                  <Button variant="ghost" size="sm" className="text-sm">
                    Login
                  </Button>
                </Link>
                <Link href="/auth">
                  <Button 
                    size="sm" 
                    className="bg-gradient-to-r from-amber-400 to-purple-500 hover:from-purple-500 hover:to-amber-400 text-black"
                  >
                    Sign Up
                  </Button>
                </Link>
              </>
            )}

            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent className="bg-gray-900 border-gray-800">
                <div className="flex flex-col gap-6 mt-8">
                  {navItems.map((item) => (
                    <Link key={item.name} href={item.path}>
                      <a 
                        className={`text-lg transition duration-300 ${
                          location === item.path
                            ? "text-white"
                            : "text-gray-400 hover:text-amber-400"
                        }`}
                        onClick={() => setIsMobileMenuOpen(false)}
                      >
                        {item.name}
                      </a>
                    </Link>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}

// Placeholder components - replace with actual content
export function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>This is placeholder about content.</p>
    </div>
  );
}

export function FAQ() {
  return (
    <div>
      <h1>Frequently Asked Questions</h1>
      <p>This is placeholder FAQ content.</p>
    </div>
  );
}