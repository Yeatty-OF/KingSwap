import { motion } from "framer-motion";

interface StepCardProps {
  number: number;
  title: string;
  description: string;
  isLast?: boolean;
}

export function StepCard({ number, title, description, isLast = false }: StepCardProps) {
  return (
    <div className="text-center relative">
      <motion.div 
        className="w-16 h-16 bg-gradient-to-r from-amber-400 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6"
        whileHover={{ scale: 1.1 }}
      >
        <span className="text-black text-2xl font-bold">{number}</span>
      </motion.div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-400">{description}</p>
      
      {!isLast && (
        <div className="hidden md:block absolute top-10 right-0 transform translate-x-1/2">
          <motion.div
            animate={{ x: [0, 5, 0] }}
            transition={{ 
              repeat: Infinity, 
              duration: 1.5 
            }}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-amber-400 opacity-50">
              <path d="M9 6L15 12L9 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </motion.div>
        </div>
      )}
    </div>
  );
}
