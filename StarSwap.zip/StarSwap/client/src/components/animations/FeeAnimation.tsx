import { motion } from "framer-motion";

interface FeeAnimationProps {
  feePercentage: number;
}

export function FeeAnimation({ feePercentage }: FeeAnimationProps) {
  return (
    <motion.div 
      className="inline-flex items-center"
      animate={{ scale: [1, 1.1, 1] }}
      transition={{ 
        repeat: Infinity, 
        repeatType: "reverse", 
        duration: 2,
        repeatDelay: 3
      }}
    >
      <span className="mr-1">Fee: </span>
      <span className="text-amber-400 font-medium">{feePercentage}%</span>
      <motion.span 
        className="ml-1"
        animate={{ 
          opacity: [0.7, 1, 0.7],
          scale: [1, 1.2, 1]
        }}
        transition={{ 
          repeat: Infinity, 
          duration: 2,
          repeatType: "reverse"
        }}
      >
        ✨
      </motion.span>
    </motion.div>
  );
}
