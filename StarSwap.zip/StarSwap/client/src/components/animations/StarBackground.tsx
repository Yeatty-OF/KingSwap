import { useEffect, useRef } from "react";

type Star = {
  x: number;
  y: number;
  size: number;
  opacity: number;
  duration: number;
};

type ShootingStar = {
  x: number;
  y: number;
  duration: number;
  delay: number;
};

export function StarBackground() {
  const starsContainerRef = useRef<HTMLDivElement>(null);
  const shootingStarsRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!starsContainerRef.current || !shootingStarsRef.current) return;
    
    const createStars = () => {
      if (!starsContainerRef.current) return;
      
      starsContainerRef.current.innerHTML = '';
      const { width, height } = starsContainerRef.current.getBoundingClientRect();
      const starCount = Math.floor(width * height / 1000);
      
      const stars: Star[] = Array.from({ length: starCount }).map(() => ({
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.4 + 0.3,
        duration: Math.random() * 3 + 2,
      }));
      
      stars.forEach(star => {
        const starElement = document.createElement('div');
        starElement.classList.add('absolute', 'rounded-full', 'animate-twinkle');
        starElement.style.left = `${star.x}%`;
        starElement.style.top = `${star.y}%`;
        starElement.style.width = `${star.size}px`;
        starElement.style.height = `${star.size}px`;
        starElement.style.opacity = `${star.opacity}`;
        starElement.style.background = 'white';
        starElement.style.animation = `twinkle ${star.duration}s ease-in-out infinite`;
        starsContainerRef.current?.appendChild(starElement);
      });
    };
    
    const createShootingStars = () => {
      if (!shootingStarsRef.current) return;
      
      shootingStarsRef.current.innerHTML = '';
      
      const shootingStars: ShootingStar[] = Array.from({ length: 3 }).map(() => ({
        x: Math.random() * 100,
        y: Math.random() * 100,
        duration: 5,
        delay: Math.random() * 15,
      }));
      
      shootingStars.forEach(star => {
        const shootingStarElement = document.createElement('div');
        shootingStarElement.classList.add('absolute', 'w-20', 'h-px');
        shootingStarElement.style.left = `${star.x}%`;
        shootingStarElement.style.top = `${star.y}%`;
        shootingStarElement.style.background = 'linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,1) 100%)';
        shootingStarElement.style.transform = 'rotate(45deg)';
        shootingStarElement.style.animation = `shoot ${star.duration}s linear infinite`;
        shootingStarElement.style.animationDelay = `${star.delay}s`;
        shootingStarElement.style.opacity = '0';
        shootingStarsRef.current?.appendChild(shootingStarElement);
      });
    };
    
    createStars();
    createShootingStars();
    
    const handleResize = () => {
      createStars();
      createShootingStars();
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  return (
    <>
      <style jsx>{`
        @keyframes twinkle {
          0%, 100% { opacity: var(--opacity, 0.7); }
          50% { opacity: 0.3; }
        }
        
        @keyframes shoot {
          0% {
            transform: translateX(-100px) translateY(-100px) rotate(45deg);
            opacity: 0;
          }
          5% {
            opacity: 1;
          }
          20% {
            transform: translateX(100vw) translateY(100vh) rotate(45deg);
            opacity: 0;
          }
          100% {
            opacity: 0;
          }
        }
      `}</style>
      <div ref={starsContainerRef} className="fixed inset-0 z-0 overflow-hidden" />
      <div ref={shootingStarsRef} className="fixed inset-0 z-0 overflow-hidden" />
    </>
  );
}
