import { motion } from "framer-motion";

type CryptoData = {
  symbol: string;
  color: string;
  textSymbol: string;
};

const CRYPTO_SYMBOLS: Record<string, CryptoData> = {
  BTC: { symbol: "₿", color: "bg-orange-500", textSymbol: "₿" },
  ETH: { symbol: "Ξ", color: "bg-blue-500", textSymbol: "Ξ" },
  BNB: { symbol: "B", color: "bg-yellow-500", textSymbol: "B" },
  SOL: { symbol: "S", color: "bg-green-500", textSymbol: "S" },
  XRP: { symbol: "X", color: "bg-indigo-500", textSymbol: "X" },
  ADA: { symbol: "A", color: "bg-blue-600", textSymbol: "A" },
  DOGE: { symbol: "D", color: "bg-yellow-400", textSymbol: "D" },
  DOT: { symbol: "•", color: "bg-pink-500", textSymbol: "•" },
};

interface CryptoLogoProps {
  cryptoSymbol: string;
  size?: "sm" | "md" | "lg";
}

export function CryptoLogo({ cryptoSymbol, size = "md" }: CryptoLogoProps) {
  const crypto = CRYPTO_SYMBOLS[cryptoSymbol] || {
    symbol: cryptoSymbol.charAt(0),
    color: "bg-gray-500",
    textSymbol: cryptoSymbol.charAt(0),
  };
  
  const sizeClasses = {
    sm: "w-5 h-5 text-xs",
    md: "w-6 h-6 text-sm",
    lg: "w-10 h-10 text-xl",
  };

  return (
    <motion.div
      className={`${sizeClasses[size]} ${crypto.color} rounded-full flex items-center justify-center font-bold text-white`}
      animate={{ 
        opacity: [0.9, 1, 0.9],
        scale: [1, 1.05, 1],
      }}
      transition={{ 
        repeat: Infinity, 
        duration: 3,
        repeatType: "reverse"
      }}
    >
      {crypto.textSymbol}
    </motion.div>
  );
}
