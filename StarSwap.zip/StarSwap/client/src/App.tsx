import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import AdminPage from "@/pages/admin-page";
import AboutPage from "@/pages/about-page";
import FAQPage from "@/pages/faq-page";
import { ProtectedRoute } from "./lib/protected-route";
import SecurityPage from "./pages/security-page";
import TermsPage from "./pages/terms-page";
import ApiDocsPage from "./pages/api-docs-page";
import HelpCenterPage from "./pages/help-center-page";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/admin" component={AdminPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/faq" component={FAQPage} />
      <Route path="/security" component={SecurityPage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/docs/api" component={ApiDocsPage} />
      <Route path="/help" component={HelpCenterPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;